When updating to a new version of the eidith package (or downgrading), be sure to run
`ed_db_download()` afterwards to update your databse.

You can install previous versions of eidith from GitHub using the **devtools**
package, like so:

```
devtools::install_github('ecohealthalliance/eidith@v0.1.0')`
```
# eidith 0.3

## New functionality

- Additional functionality for FASTA export and interpretation: `ed_fasta_group()`,
  `ed_report_excel()`.
- Mock data sets now available: `ed_table_mock()`
- EIDITH table connections now listed in dataframe via `ed_tables_conn()`
- Database downloads more robust to errors, only overwrites old data after new data is checked

## New documentation

- Automatic Processing / Raw Data vignette
- Data Structure and Table Joining vignette with mock data example
- Report generation and FASTA file vignette

## *Breaking changes in data processing*

- New `human_health` field in viruses flags human health risk, old `evidence_human_infection` field is removed.
- Reordering metadata to make more intelligible.
- Change `virus_id` to `sequence_id`.
- Make lat/long numeric and compatible with `SpatialPointsDataFrame`
- Altering `date_created`, `date_modified`, and `database_date` fields to reflect tables, e.g `date_created_animals` or `database_date_specimens`.
- The `sequence` field in `tests` table has been renamed `test_sequences` to avoid confusion
- The `interpretation` field in `tests` table has been renamed `test_interpretations` to avoid confusion
- The `specimen_type` field in `tests` tables has been renamed `specimen_type_test` and the `speciment_type_group` has been renamed `specimen_type_group_test` to avoid confusion.

__Note: A new local database download (`ed_db_download`) will be needed for the user to see these data processing changes. The change in field names may break previous scripts, the user should consider saving current state of their local database using `ed_db_export()`.__



# eidith 0.2.2 (patch)

- Switch API endpoints to new URLs

# eidith 0.2.1 (patch)

- Fix bug in `ed_table_` when parsing long expressions, showing up in
  `ed_tests_report()`

# eidith 0.2.0

## New functionality

- Add a FASTA export function: `ed_fasta()`
- Add a function for reports on recents tests: `ed_tests_report()`

## Changes to data processing

 - New column in tests table - `diag_lab_shortname` - an abbreviated lab name for easier reporting
 - Renamed `known_human_risk` to `evidence_human_infection` and added more clarifying text to metadata
 - Taxagroups are now one-to-one mapped to orders. `ed_taxagroups()` will return a table with the
   mapping between them.  Metadata notes updated to reflect this. (See [Issue #32](https://github.com/ecohealthalliance/eidith/issues/32))
 
## Bug Fixes

 - No longer fail when database extracts are zero-length
 
## Changes to development

 - Moved to separate stable (`master`) and development (`dev`) branches. Stable
   branch can now be installed without devtools.
 - Set up continuous integration tests, run daily, for all main OSs and R versions. These will tell us if patches
   or new data break something in the package.
 
# eidith v0.1.0

* Add documentation of web API

# eidith v0.0.1

* Beta release
* Database download, management, and data extraction functions in stable
  form and documented

# eidith v0.0.0.9000

* Initial development version


