# eidith 0.1.0

* Add documentation of web API

# eidith 0.0.1

* Beta release
* Database download, management, and data extraction functions in stable
  form and documented

# eidith 0.0.0.9000

* Initial development version



