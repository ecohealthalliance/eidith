library(testthat)
library(eidith)

test_check("eidith")

