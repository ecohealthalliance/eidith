

```r
library(dplyr)

df <- tibble(
  x = 1:4,
  y = 3:6
)
df
df %>%
  mutate(z = x > 2)
df %>%
  mutate(z = y > 2)
df %>%
  mutate(z = x > 2 + y > 2)
```

```
## Error: <text>:13:24: unexpected '>'
## 12: df %>%
## 13:   mutate(z = x > 2 + y >
##                            ^
```

